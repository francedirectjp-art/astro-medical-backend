from flask import Flask, request, jsonify
from flask_cors import CORS
import swisseph as swe
from datetime import datetime
import os

app = Flask(__name__)
CORS(app)

# 47都道府県の座標データ
PREFECTURES = {
    '北海道札幌市': (43.0642, 141.3469),
    '青森県青森市': (40.8244, 140.7400),
    '岩手県盛岡市': (39.7036, 141.1527),
    '宮城県仙台市': (38.2682, 140.8694),
    '秋田県秋田市': (39.7186, 140.1024),
    '山形県山形市': (38.2404, 140.3633),
    '福島県福島市': (37.7608, 140.4747),
    '茨城県水戸市': (36.3418, 140.4468),
    '栃木県宇都宮市': (36.5658, 139.8836),
    '群馬県前橋市': (36.3911, 139.0608),
    '埼玉県さいたま市': (35.8617, 139.6455),
    '千葉県千葉市': (35.6074, 140.1065),
    '東京都新宿区': (35.6938, 139.7036),
    '神奈川県横浜市': (35.4478, 139.6425),
    '新潟県新潟市': (37.9161, 139.0364),
    '富山県富山市': (36.6959, 137.2139),
    '石川県金沢市': (36.5946, 136.6256),
    '福井県福井市': (36.0652, 136.2217),
    '山梨県甲府市': (35.6642, 138.5683),
    '長野県長野市': (36.6513, 138.1811),
    '岐阜県岐阜市': (35.3912, 136.7223),
    '静岡県静岡市': (34.9756, 138.3828),
    '愛知県名古屋市': (35.1815, 136.9066),
    '三重県津市': (34.7303, 136.5086),
    '滋賀県大津市': (35.0045, 135.8686),
    '京都府京都市': (35.0116, 135.7681),
    '大阪府大阪市': (34.6937, 135.5023),
    '兵庫県神戸市': (34.6901, 135.1956),
    '奈良県奈良市': (34.6851, 135.8048),
    '和歌山県和歌山市': (34.2261, 135.1675),
    '鳥取県鳥取市': (35.5014, 134.2378),
    '島根県松江市': (35.4723, 133.0505),
    '岡山県岡山市': (34.6617, 133.9341),
    '広島県広島市': (34.3853, 132.4553),
    '山口県山口市': (34.1858, 131.4706),
    '徳島県徳島市': (34.0658, 134.5594),
    '香川県高松市': (34.3401, 134.0431),
    '愛媛県松山市': (33.8416, 132.7658),
    '高知県高知市': (33.5597, 133.5311),
    '福岡県福岡市': (33.6064, 130.4181),
    '佐賀県佐賀市': (33.2494, 130.2989),
    '長崎県長崎市': (32.7503, 129.8779),
    '熊本県熊本市': (32.7898, 130.7417),
    '大分県大分市': (33.2382, 131.6126),
    '宮崎県宮崎市': (31.9077, 131.4202),
    '鹿児島県鹿児島市': (31.5966, 130.5571),
    '沖縄県那覇市': (26.2124, 127.6792)
}

def get_sign_japanese(sign_abbr):
    """星座の英語略称を日本語に変換"""
    signs = {
        'Ari': '牡羊座', 'Tau': '牡牛座', 'Gem': '双子座', 'Can': '蟹座',
        'Leo': '獅子座', 'Vir': '乙女座', 'Lib': '天秤座', 'Sco': '蠍座',
        'Sag': '射手座', 'Cap': '山羊座', 'Aqu': '水瓶座', 'Pis': '魚座'
    }
    return signs.get(sign_abbr, sign_abbr)

def degree_to_sign_and_degree(longitude):
    """黄経度数を星座と度数に変換"""
    signs = ['Ari', 'Tau', 'Gem', 'Can', 'Leo', 'Vir', 'Lib', 'Sco', 'Sag', 'Cap', 'Aqu', 'Pis']
    sign_index = int(longitude // 30)
    degree_in_sign = longitude % 30
    return signs[sign_index], degree_in_sign

def get_location_coordinates(birth_place):
    """出生地から座標を取得"""
    return PREFECTURES.get(birth_place, (35.6938, 139.7036))  # デフォルトは東京

@app.route('/api/astrology/calculate', methods=['POST'])
def calculate_astrology():
    try:
        data = request.get_json()
        
        name = data.get('name', '')
        birth_date = data.get('birthDate', '')
        birth_time = data.get('birthTime', '')
        birth_place = data.get('birthPlace', '')
        
        print(f"計算開始: {name}, {birth_date} {birth_time}, {birth_place}")
        
        # 日時の解析
        year, month, day = map(int, birth_date.split('-'))
        hour, minute = map(int, birth_time.split(':'))
        
        # 座標の取得
        latitude, longitude = get_location_coordinates(birth_place)
        
        # JST-9時間でUTC変換
        utc_hour = hour - 9
        utc_day = day
        if utc_hour < 0:
            utc_hour += 24
            utc_day -= 1
        elif utc_hour >= 24:
            utc_hour -= 24
            utc_day += 1
        
        # ユリウス日の計算
        jd = swe.julday(year, month, utc_day, utc_hour + minute / 60.0)
        
        print(f"ユリウス日: {jd}")
        
        # 惑星の計算
        planets_data = []
        
        # 主要7惑星
        planet_ids = [
            (swe.SUN, 'Sun', '太陽'),
            (swe.MOON, 'Moon', '月'),
            (swe.MERCURY, 'Mercury', '水星'),
            (swe.VENUS, 'Venus', '金星'),
            (swe.MARS, 'Mars', '火星'),
            (swe.JUPITER, 'Jupiter', '木星'),
            (swe.SATURN, 'Saturn', '土星')
        ]
        
        for planet_id, planet_en, planet_jp in planet_ids:
            result, ret_flag = swe.calc_ut(jd, planet_id)
            longitude = result[0]
            speed = result[3]
            
            sign, degree_in_sign = degree_to_sign_and_degree(longitude)
            
            planets_data.append({
                'name_jp': planet_jp,
                'name_en': planet_en,
                'sign': sign,
                'sign_jp': get_sign_japanese(sign),
                'degree': round(degree_in_sign, 2),
                'longitude': round(longitude, 2),
                'retrograde': speed < 0
            })
        
        # ドラゴンヘッド（ノースノード）
        result, ret_flag = swe.calc_ut(jd, swe.MEAN_NODE)
        node_longitude = result[0]
        node_speed = result[3]
        node_sign, node_degree = degree_to_sign_and_degree(node_longitude)
        
        planets_data.append({
            'name_jp': 'ドラゴンヘッド',
            'name_en': 'North_Node',
            'sign': node_sign,
            'sign_jp': get_sign_japanese(node_sign),
            'degree': round(node_degree, 2),
            'longitude': round(node_longitude, 2),
            'retrograde': node_speed < 0
        })
        
        # アセンダントとミッドヘブンの計算
        houses, ascmc = swe.houses(jd, latitude, longitude, b'P')  # Placidusハウスシステム
        
        # アセンダント
        asc_longitude = ascmc[0]
        asc_sign, asc_degree = degree_to_sign_and_degree(asc_longitude)
        
        # ミッドヘブン
        mc_longitude = ascmc[1]
        mc_sign, mc_degree = degree_to_sign_and_degree(mc_longitude)
        
        planets_data.append({
            'name_jp': 'ミッドヘブン',
            'name_en': 'Midheaven',
            'sign': mc_sign,
            'sign_jp': get_sign_japanese(mc_sign),
            'degree': round(mc_degree, 2),
            'longitude': round(mc_longitude, 2),
            'retrograde': False
        })
        
        ascendant = {
            'sign': asc_sign,
            'sign_jp': get_sign_japanese(asc_sign),
            'degree': round(asc_degree, 2),
            'longitude': round(asc_longitude, 2)
        }
        
        result = {
            'name': name,
            'birth_info': {
                'date': f"{year}年{month:02d}月{day:02d}日",
                'time': birth_time,
                'place': birth_place
            },
            'calculation_method': 'Swiss Ephemeris (High Precision)',
            'planets': planets_data,
            'ascendant': ascendant
        }
        
        print(f"計算完了: {len(planets_data)}個の天体")
        return jsonify(result)
        
    except Exception as e:
        print(f"エラー: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({'status': 'healthy', 'service': 'Swiss Ephemeris Astrology API'})

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)

