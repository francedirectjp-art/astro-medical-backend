# Swiss Ephemeris 占星医学体質診断 API

高精度な占星術計算を提供するFlask APIです。Swiss Ephemerisライブラリを使用して、業界標準の精度で天体位置を計算します。

## 機能

- 主要7惑星（太陽、月、水星、金星、火星、木星、土星）の位置計算
- アセンダント、ミッドヘブン、ドラゴンヘッドの計算
- 47都道府県対応
- 逆行情報の判定
- 日本語対応

## API エンドポイント

### POST /api/astrology/calculate

占星術チャートを計算します。

**リクエスト例:**
```json
{
  "name": "山田太郎",
  "birthDate": "1990-05-15",
  "birthTime": "14:30",
  "birthPlace": "東京都新宿区"
}
```

**レスポンス例:**
```json
{
  "name": "山田太郎",
  "birth_info": {
    "date": "1990年05月15日",
    "time": "14:30",
    "place": "東京都新宿区"
  },
  "calculation_method": "Swiss Ephemeris (High Precision)",
  "planets": [
    {
      "name_jp": "太陽",
      "name_en": "Sun",
      "sign": "Tau",
      "sign_jp": "牡牛座",
      "degree": 24.13,
      "longitude": 54.13,
      "retrograde": false
    }
  ],
  "ascendant": {
    "sign": "Lib",
    "sign_jp": "天秤座",
    "degree": 16.83,
    "longitude": 196.83
  }
}
```

## デプロイ

Railway.appでのデプロイに最適化されています。

1. GitHubリポジトリをフォーク
2. Railway.appでアカウント作成
3. "Deploy from GitHub repo"を選択
4. 自動デプロイ完了

## 技術仕様

- Python 3.11+
- Flask 2.3.3
- pyswisseph 2.10.3.2
- Swiss Ephemeris DE431天体暦

## ライセンス

MIT License

